
# Análise de Discrepância no preço de Venda de Produtos

## Dúvida da área de negócios
* **Será que nossos diferentes lojistas associados conseguem manter o preço do mesmo produto sem grandes discrepâncias?**

* **Resposta:** Com base nas análises realizadas, chegou-se a conclusão de que o preço de um mesmo produto é mantido **sim** sem grandes discrepâncias. Para responder esta questão foi utilizado como base medidas de dispersão. Utilizando a medida de dispersão **desvio padrão** viu-se que 82.12% dos produtos não sofrem variações no preço de venda, e que 17.88% sofrem variações. E utilizando a medida de dispersão **variância** viu-se que 82.41% dos produtos não sofrem variações no preço de venda, e que 17.59% sofrem variações. 


```python
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import plotly.offline as py
import plotly.graph_objs as go
```


```python
%matplotlib inline

from IPython.core.pylabtools import figsize


figsize(12, 8)

sns.set()
```

## Carregando bases de dados


```python
df_customers = pd.read_csv('datasets/olist_customers_dataset.csv', encoding='ISO-8859-1')
df_geolocation = pd.read_csv('datasets/olist_geolocation_dataset.csv', encoding='ISO-8859-1')
df_order_items = pd.read_csv('datasets/olist_order_items_dataset.csv', encoding='ISO-8859-1')
df_order_payments = pd.read_csv('datasets/olist_order_payments_dataset.csv', encoding='ISO-8859-1')
df_order_reviews = pd.read_csv('datasets/olist_order_reviews_dataset.csv', encoding='ISO-8859-1')
df_orders = pd.read_csv('datasets/olist_orders_dataset.csv', encoding='ISO-8859-1')
df_products = pd.read_csv('datasets/olist_products_dataset.csv', encoding='ISO-8859-1')
df_sellers = pd.read_csv('datasets/olist_sellers_dataset.csv', encoding='ISO-8859-1')
df_product_category_name_translation = pd.read_csv('datasets/product_category_name_translation.csv', encoding='ISO-8859-1')
```

## Base de Clientes


```python
df_customers.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>customer_unique_id</th>
      <th>customer_zip_code_prefix</th>
      <th>customer_city</th>
      <th>customer_state</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>06b8999e2fba1a1fbc88172c00ba8bc7</td>
      <td>861eff4711a542e4b93843c6dd7febb0</td>
      <td>14409</td>
      <td>franca</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>1</th>
      <td>18955e83d337fd6b2def6b18a428ac77</td>
      <td>290c77bc529b7ac935b93aa66c333dc3</td>
      <td>9790</td>
      <td>sao bernardo do campo</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4e7b3e00288586ebd08712fdd0374a03</td>
      <td>060e732b5b29e8181a18229c7b0b2b5e</td>
      <td>1151</td>
      <td>sao paulo</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>3</th>
      <td>b2b6027bc5c5109e529d4dc6358b12c3</td>
      <td>259dac757896d24d7702b9acbbff3f3c</td>
      <td>8775</td>
      <td>mogi das cruzes</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4f2d8ab171c80ec8364f7c12e35b23ad</td>
      <td>345ecd01c38d18a9036ed96c73b8d066</td>
      <td>13056</td>
      <td>campinas</td>
      <td>SP</td>
    </tr>
  </tbody>
</table>
</div>



## Base de Lojistas


```python
df_sellers.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>seller_id</th>
      <th>seller_zip_code_prefix</th>
      <th>seller_city</th>
      <th>seller_state</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3442f8959a84dea7ee197c632cb2df15</td>
      <td>13023</td>
      <td>campinas</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>1</th>
      <td>d1b65fc7debc3361ea86b5f14c68d2e2</td>
      <td>13844</td>
      <td>mogi guacu</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>2</th>
      <td>ce3ad9de960102d0677a81f5d0bb7b2d</td>
      <td>20031</td>
      <td>rio de janeiro</td>
      <td>RJ</td>
    </tr>
    <tr>
      <th>3</th>
      <td>c0f3eea2e14555b6faeea3dd58c1b1c3</td>
      <td>4195</td>
      <td>sao paulo</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>4</th>
      <td>51a04a8a6bdcb23deccc82b0b80742cf</td>
      <td>12914</td>
      <td>braganca paulista</td>
      <td>SP</td>
    </tr>
  </tbody>
</table>
</div>



## Base de Geolocalizações


```python
df_geolocation.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geolocation_zip_code_prefix</th>
      <th>geolocation_lat</th>
      <th>geolocation_lng</th>
      <th>geolocation_city</th>
      <th>geolocation_state</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1037</td>
      <td>-23.545621</td>
      <td>-46.639292</td>
      <td>sao paulo</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1046</td>
      <td>-23.546081</td>
      <td>-46.644820</td>
      <td>sao paulo</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1046</td>
      <td>-23.546129</td>
      <td>-46.642951</td>
      <td>sao paulo</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1041</td>
      <td>-23.544392</td>
      <td>-46.639499</td>
      <td>sao paulo</td>
      <td>SP</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1035</td>
      <td>-23.541578</td>
      <td>-46.641607</td>
      <td>sao paulo</td>
      <td>SP</td>
    </tr>
  </tbody>
</table>
</div>



## Base de Pedidos


```python
df_orders.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>customer_id</th>
      <th>order_status</th>
      <th>order_purchase_timestamp</th>
      <th>order_approved_at</th>
      <th>order_delivered_carrier_date</th>
      <th>order_delivered_customer_date</th>
      <th>order_estimated_delivery_date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>e481f51cbdc54678b7cc49136f2d6af7</td>
      <td>9ef432eb6251297304e76186b10a928d</td>
      <td>delivered</td>
      <td>2017-10-02 10:56:33</td>
      <td>2017-10-02 11:07:15</td>
      <td>2017-10-04 19:55:00</td>
      <td>2017-10-10 21:25:13</td>
      <td>2017-10-18 00:00:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>53cdb2fc8bc7dce0b6741e2150273451</td>
      <td>b0830fb4747a6c6d20dea0b8c802d7ef</td>
      <td>delivered</td>
      <td>2018-07-24 20:41:37</td>
      <td>2018-07-26 03:24:27</td>
      <td>2018-07-26 14:31:00</td>
      <td>2018-08-07 15:27:45</td>
      <td>2018-08-13 00:00:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>47770eb9100c2d0c44946d9cf07ec65d</td>
      <td>41ce2a54c0b03bf3443c3d931a367089</td>
      <td>delivered</td>
      <td>2018-08-08 08:38:49</td>
      <td>2018-08-08 08:55:23</td>
      <td>2018-08-08 13:50:00</td>
      <td>2018-08-17 18:06:29</td>
      <td>2018-09-04 00:00:00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>949d5b44dbf5de918fe9c16f97b45f8a</td>
      <td>f88197465ea7920adcdbec7375364d82</td>
      <td>delivered</td>
      <td>2017-11-18 19:28:06</td>
      <td>2017-11-18 19:45:59</td>
      <td>2017-11-22 13:39:59</td>
      <td>2017-12-02 00:28:42</td>
      <td>2017-12-15 00:00:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>ad21c59c0840e6cb83a9ceb5573f8159</td>
      <td>8ab97904e6daea8866dbdbc4fb7aad2c</td>
      <td>delivered</td>
      <td>2018-02-13 21:18:39</td>
      <td>2018-02-13 22:20:29</td>
      <td>2018-02-14 19:46:34</td>
      <td>2018-02-16 18:17:02</td>
      <td>2018-02-26 00:00:00</td>
    </tr>
  </tbody>
</table>
</div>



## Itens do pedido


```python
df_order_items.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>order_item_id</th>
      <th>product_id</th>
      <th>seller_id</th>
      <th>shipping_limit_date</th>
      <th>price</th>
      <th>freight_value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>00010242fe8c5a6d1ba2dd792cb16214</td>
      <td>1</td>
      <td>4244733e06e7ecb4970a6e2683c13e61</td>
      <td>48436dade18ac8b2bce089ec2a041202</td>
      <td>2017-09-19 09:45:35</td>
      <td>58.90</td>
      <td>13.29</td>
    </tr>
    <tr>
      <th>1</th>
      <td>00018f77f2f0320c557190d7a144bdd3</td>
      <td>1</td>
      <td>e5f2d52b802189ee658865ca93d83a8f</td>
      <td>dd7ddc04e1b6c2c614352b383efe2d36</td>
      <td>2017-05-03 11:05:13</td>
      <td>239.90</td>
      <td>19.93</td>
    </tr>
    <tr>
      <th>2</th>
      <td>000229ec398224ef6ca0657da4fc703e</td>
      <td>1</td>
      <td>c777355d18b72b67abbeef9df44fd0fd</td>
      <td>5b51032eddd242adc84c38acab88f23d</td>
      <td>2018-01-18 14:48:30</td>
      <td>199.00</td>
      <td>17.87</td>
    </tr>
    <tr>
      <th>3</th>
      <td>00024acbcdf0a6daa1e931b038114c75</td>
      <td>1</td>
      <td>7634da152a4610f1595efa32f14722fc</td>
      <td>9d7a1d34a5052409006425275ba1c2b4</td>
      <td>2018-08-15 10:10:18</td>
      <td>12.99</td>
      <td>12.79</td>
    </tr>
    <tr>
      <th>4</th>
      <td>00042b26cf59d7ce69dfabb4e55b4fd9</td>
      <td>1</td>
      <td>ac6c3623068f30de03045865e4e10089</td>
      <td>df560393f3a51e74553ab94004ba5c87</td>
      <td>2017-02-13 13:57:51</td>
      <td>199.90</td>
      <td>18.14</td>
    </tr>
  </tbody>
</table>
</div>



## Forma de pagamento de cada pedido


```python
df_order_payments.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>payment_sequential</th>
      <th>payment_type</th>
      <th>payment_installments</th>
      <th>payment_value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>b81ef226f3fe1789b1e8b2acac839d17</td>
      <td>1</td>
      <td>credit_card</td>
      <td>8</td>
      <td>99.33</td>
    </tr>
    <tr>
      <th>1</th>
      <td>a9810da82917af2d9aefd1278f1dcfa0</td>
      <td>1</td>
      <td>credit_card</td>
      <td>1</td>
      <td>24.39</td>
    </tr>
    <tr>
      <th>2</th>
      <td>25e8ea4e93396b6fa0d3dd708e76c1bd</td>
      <td>1</td>
      <td>credit_card</td>
      <td>1</td>
      <td>65.71</td>
    </tr>
    <tr>
      <th>3</th>
      <td>ba78997921bbcdc1373bb41e913ab953</td>
      <td>1</td>
      <td>credit_card</td>
      <td>8</td>
      <td>107.78</td>
    </tr>
    <tr>
      <th>4</th>
      <td>42fdf880ba16b47b59251dd489d4441a</td>
      <td>1</td>
      <td>credit_card</td>
      <td>2</td>
      <td>128.45</td>
    </tr>
  </tbody>
</table>
</div>



## Retorno de clientes sobre a compra realizada


```python
df_order_reviews.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>review_id</th>
      <th>order_id</th>
      <th>review_score</th>
      <th>review_comment_title</th>
      <th>review_comment_message</th>
      <th>review_creation_date</th>
      <th>review_answer_timestamp</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7bc2406110b926393aa56f80a40eba40</td>
      <td>73fc7af87114b39712e6da79b0a377eb</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2018-01-18 00:00:00</td>
      <td>2018-01-18 21:46:59</td>
    </tr>
    <tr>
      <th>1</th>
      <td>80e641a11e56f04c1ad469d5645fdfde</td>
      <td>a548910a1c6147796b98fdf73dbeba33</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2018-03-10 00:00:00</td>
      <td>2018-03-11 03:05:13</td>
    </tr>
    <tr>
      <th>2</th>
      <td>228ce5500dc1d8e020d8d1322874b6f0</td>
      <td>f9e4b658b201a9f2ecdecbb34bed034b</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2018-02-17 00:00:00</td>
      <td>2018-02-18 14:36:24</td>
    </tr>
    <tr>
      <th>3</th>
      <td>e64fb393e7b32834bb789ff8bb30750e</td>
      <td>658677c97b385a9be170737859d3511b</td>
      <td>5</td>
      <td>NaN</td>
      <td>Recebi bem antes do prazo estipulado.</td>
      <td>2017-04-21 00:00:00</td>
      <td>2017-04-21 22:02:06</td>
    </tr>
    <tr>
      <th>4</th>
      <td>f7c4243c7fe1938f181bec41a392bdeb</td>
      <td>8e6bfb81e283fa7e4f11123a3fb894f1</td>
      <td>5</td>
      <td>NaN</td>
      <td>ParabÃ©ns lojas lannister adorei comprar pela ...</td>
      <td>2018-03-01 00:00:00</td>
      <td>2018-03-02 10:26:53</td>
    </tr>
  </tbody>
</table>
</div>



## Dados cadastrais de cada produto


```python
df_products.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_id</th>
      <th>product_category_name</th>
      <th>product_name_lenght</th>
      <th>product_description_lenght</th>
      <th>product_photos_qty</th>
      <th>product_weight_g</th>
      <th>product_length_cm</th>
      <th>product_height_cm</th>
      <th>product_width_cm</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1e9e8ef04dbcff4541ed26657ea517e5</td>
      <td>perfumaria</td>
      <td>40.0</td>
      <td>287.0</td>
      <td>1.0</td>
      <td>225.0</td>
      <td>16.0</td>
      <td>10.0</td>
      <td>14.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3aa071139cb16b67ca9e5dea641aaa2f</td>
      <td>artes</td>
      <td>44.0</td>
      <td>276.0</td>
      <td>1.0</td>
      <td>1000.0</td>
      <td>30.0</td>
      <td>18.0</td>
      <td>20.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>96bd76ec8810374ed1b65e291975717f</td>
      <td>esporte_lazer</td>
      <td>46.0</td>
      <td>250.0</td>
      <td>1.0</td>
      <td>154.0</td>
      <td>18.0</td>
      <td>9.0</td>
      <td>15.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>cef67bcfe19066a932b7673e239eb23d</td>
      <td>bebes</td>
      <td>27.0</td>
      <td>261.0</td>
      <td>1.0</td>
      <td>371.0</td>
      <td>26.0</td>
      <td>4.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9dc1a7de274444849c219cff195d0b71</td>
      <td>utilidades_domesticas</td>
      <td>37.0</td>
      <td>402.0</td>
      <td>4.0</td>
      <td>625.0</td>
      <td>20.0</td>
      <td>17.0</td>
      <td>13.0</td>
    </tr>
  </tbody>
</table>
</div>



## Tradução das categorias de produtos


```python
df_product_category_name_translation.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_category_name</th>
      <th>product_category_name_english</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>beleza_saude</td>
      <td>health_beauty</td>
    </tr>
    <tr>
      <th>1</th>
      <td>informatica_acessorios</td>
      <td>computers_accessories</td>
    </tr>
    <tr>
      <th>2</th>
      <td>automotivo</td>
      <td>auto</td>
    </tr>
    <tr>
      <th>3</th>
      <td>cama_mesa_banho</td>
      <td>bed_bath_table</td>
    </tr>
    <tr>
      <th>4</th>
      <td>moveis_decoracao</td>
      <td>furniture_decor</td>
    </tr>
  </tbody>
</table>
</div>



## Criando um dataset para receber dados dos produtos, tais como: 
* <strong>PRODUCT_ID</strong> - id do produto
* <strong>SELLER_ID</strong> - id do vendedor
* <strong>STD_PRICE</strong> - desvio padrão do preço
* <strong>MEAN_PRICE</strong> - média de preço
* <strong>VAR_PRICE</strong> - variância do preço
* <strong>MIN_PRICE</strong> - preço de venda mínimo
* <strong>MAX_PRICE</strong> - preço de venda máximo
* <strong>COUNT_ORDER</strong> - quantidade de pedidos de cada produto
* <strong>COUNT_VAR_PRICE</strong> - quantidade de variações de preço


```python
# Definindo colunas do dataset
df_price_products = pd.DataFrame(columns=['PRODUCT_ID', 'SELLER_ID', 'STD_PRICE', 
                                          'MEAN_PRICE', 'VAR_PRICE', 'MIN_PRICE', 'MAX_PRICE', 'COUNT_ORDER', 'COUNT_VAR_PRICE'])
```

## Preenchendo o dataset **df_price_products**


```python
for product_id in df_products['product_id']:
    seller_id = df_order_items[df_order_items['product_id'] == product_id]['seller_id'].unique()
    std_price = round(df_order_items[df_order_items['product_id'] == product_id]['price'].std(),2)
    mean_price = round(df_order_items[df_order_items['product_id'] == product_id]['price'].mean(),2)
    var_price = round(df_order_items[df_order_items['product_id'] == product_id]['price'].var(),2)
    min_price = df_order_items[df_order_items['product_id'] == product_id]['price'].min()
    max_price = df_order_items[df_order_items['product_id'] == product_id]['price'].max()
    count_order = len(df_order_items[df_order_items['product_id'] == product_id])
    count_var_price = len(df_order_items[df_order_items['product_id'] == product_id]['price'].unique())
    
    df_price_products = df_price_products.append({'PRODUCT_ID':product_id, 'SELLER_ID':seller_id[0],'STD_PRICE':std_price,
                                                  'MEAN_PRICE':mean_price, 'VAR_PRICE':var_price, 'MIN_PRICE': min_price,
                                                'MAX_PRICE':max_price, 'COUNT_ORDER':count_order, 'COUNT_VAR_PRICE':count_var_price}, ignore_index=True)
```

## Exibindo algumas linhas do dataset **df_price_products** para validar se os campos foram preenchidos de forma correta


```python
df_price_products.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PRODUCT_ID</th>
      <th>SELLER_ID</th>
      <th>STD_PRICE</th>
      <th>MEAN_PRICE</th>
      <th>VAR_PRICE</th>
      <th>MIN_PRICE</th>
      <th>MAX_PRICE</th>
      <th>COUNT_ORDER</th>
      <th>COUNT_VAR_PRICE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1e9e8ef04dbcff4541ed26657ea517e5</td>
      <td>5670f4db5b62c43d542e1b2d56b0cf7c</td>
      <td>NaN</td>
      <td>10.91</td>
      <td>NaN</td>
      <td>10.91</td>
      <td>10.91</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3aa071139cb16b67ca9e5dea641aaa2f</td>
      <td>b561927807645834b59ef0d16ba55a24</td>
      <td>NaN</td>
      <td>248.00</td>
      <td>NaN</td>
      <td>248.00</td>
      <td>248.00</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>96bd76ec8810374ed1b65e291975717f</td>
      <td>7b07b3c7487f0ea825fc6df75abd658b</td>
      <td>NaN</td>
      <td>79.80</td>
      <td>NaN</td>
      <td>79.80</td>
      <td>79.80</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>cef67bcfe19066a932b7673e239eb23d</td>
      <td>c510bc1718f0f2961eaa42a23330681a</td>
      <td>NaN</td>
      <td>112.30</td>
      <td>NaN</td>
      <td>112.30</td>
      <td>112.30</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9dc1a7de274444849c219cff195d0b71</td>
      <td>0be8ff43f22e456b4e0371b2245e4d01</td>
      <td>NaN</td>
      <td>37.90</td>
      <td>NaN</td>
      <td>37.90</td>
      <td>37.90</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



## Tratando valores nulos no dataset **df_price_products**

* Ao analisar o dataset **df_price_products**, identificou-se que as colunas **STD_PRICE e VAR_PRICE** possuem valores nulos, e isso é consequência da quantidade de pedidos e por não ter variações de preço de venda do produto. Com base nessa análise, os campos nulos foram preenchidos com valor **zero**


```python
df_price_products.fillna(0, inplace=True)
```

## Exibindo algumas linhas do dataset **df_price_products**


```python
df_price_products.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>PRODUCT_ID</th>
      <th>SELLER_ID</th>
      <th>STD_PRICE</th>
      <th>MEAN_PRICE</th>
      <th>VAR_PRICE</th>
      <th>MIN_PRICE</th>
      <th>MAX_PRICE</th>
      <th>COUNT_ORDER</th>
      <th>COUNT_VAR_PRICE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1e9e8ef04dbcff4541ed26657ea517e5</td>
      <td>5670f4db5b62c43d542e1b2d56b0cf7c</td>
      <td>0.0</td>
      <td>10.91</td>
      <td>0.0</td>
      <td>10.91</td>
      <td>10.91</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3aa071139cb16b67ca9e5dea641aaa2f</td>
      <td>b561927807645834b59ef0d16ba55a24</td>
      <td>0.0</td>
      <td>248.00</td>
      <td>0.0</td>
      <td>248.00</td>
      <td>248.00</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>96bd76ec8810374ed1b65e291975717f</td>
      <td>7b07b3c7487f0ea825fc6df75abd658b</td>
      <td>0.0</td>
      <td>79.80</td>
      <td>0.0</td>
      <td>79.80</td>
      <td>79.80</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>cef67bcfe19066a932b7673e239eb23d</td>
      <td>c510bc1718f0f2961eaa42a23330681a</td>
      <td>0.0</td>
      <td>112.30</td>
      <td>0.0</td>
      <td>112.30</td>
      <td>112.30</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9dc1a7de274444849c219cff195d0b71</td>
      <td>0be8ff43f22e456b4e0371b2245e4d01</td>
      <td>0.0</td>
      <td>37.90</td>
      <td>0.0</td>
      <td>37.90</td>
      <td>37.90</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



## Salvando dataset **df_price_products** em csv


```python
df_price_products.to_csv('datasets/df_price_products')
```


```python
df_order_items[df_order_items['product_id'] == '0992c6cba95a13bfa68ea7d5e22d478b']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>order_id</th>
      <th>order_item_id</th>
      <th>product_id</th>
      <th>seller_id</th>
      <th>shipping_limit_date</th>
      <th>price</th>
      <th>freight_value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16857</th>
      <td>269bbdf003d4126d5687fbaf9542813d</td>
      <td>1</td>
      <td>0992c6cba95a13bfa68ea7d5e22d478b</td>
      <td>d50d79cb34e38265a8649c383dcffd48</td>
      <td>2017-12-28 22:38:32</td>
      <td>355.99</td>
      <td>17.25</td>
    </tr>
    <tr>
      <th>26653</th>
      <td>3c9e706b2938bbef0922d8c7da956ec8</td>
      <td>1</td>
      <td>0992c6cba95a13bfa68ea7d5e22d478b</td>
      <td>d50d79cb34e38265a8649c383dcffd48</td>
      <td>2017-08-29 02:46:54</td>
      <td>355.99</td>
      <td>28.81</td>
    </tr>
    <tr>
      <th>33431</th>
      <td>4bb2ee0b9741faceac3deb03a2e53fa6</td>
      <td>1</td>
      <td>0992c6cba95a13bfa68ea7d5e22d478b</td>
      <td>d50d79cb34e38265a8649c383dcffd48</td>
      <td>2018-08-15 11:05:13</td>
      <td>405.99</td>
      <td>36.60</td>
    </tr>
  </tbody>
</table>
</div>



## Percentual de produtos que possuem variações de preço de vendas com base no **desvio padrão**


```python
percent_no_variation = round(df_price_products[df_price_products['STD_PRICE'] == 0].shape[0] / df_price_products.shape[0] * 100,2)
percent_yes_variation = round(df_price_products[df_price_products['STD_PRICE'] > 0].shape[0] / df_price_products.shape[0] * 100,2)

print(f"Percentual com variações: {percent_yes_variation}%")
print(f"Percentual sem variações: {percent_no_variation}%")

perc = [go.Bar(x = ['COM VARIAÇÕES', 'SEM VARIAÇÕES'], y=[percent_yes_variation, percent_no_variation], marker=dict(color=['#035ee8', '#00fa9a']))]

layout = go.Layout( title='% Percentual de produtos que possuem variações de preço de vendas')

fig = go.Figure(data=perc, layout=layout)
perc = [go.Bar(x = ['COM VARIAÇÕES', 'SEM VARIAÇÕES'], y=[percent_yes_variation, percent_no_variation], marker=dict(color=['#035ee8', '#00fa9a']))]

layout = go.Layout( title='% Percentual de produtos que possuem variações de preço de vendas')

fig = go.Figure(data=perc, layout=layout)

py.iplot(fig, filename='color-bar')
```

    Percentual com variações: 17.88%
    Percentual sem variações: 82.12%



![png](output_38_1.png)


## Percentual de produtos que possuem variações de preço de vendas com base na **variância**


```python
percent_no_variation = round(df_price_products[df_price_products['VAR_PRICE'] == 0].shape[0] / df_price_products.shape[0] * 100,2)
percent_yes_variation = round(df_price_products[df_price_products['VAR_PRICE'] > 0].shape[0] / df_price_products.shape[0] * 100,2)

print(f"Percentual com variações: {percent_yes_variation}%")
print(f"Percentual sem variações: {percent_no_variation}%")

perc = [go.Bar(x = ['COM VARIAÇÕES', 'SEM VARIAÇÕES'], y=[percent_yes_variation, percent_no_variation], marker=dict(color=['#035ee8', '#00fa9a']))]

layout = go.Layout( title='% Percentual de produtos que possuem variações de preço de vendas')

fig = go.Figure(data=perc, layout=layout)

py.iplot(fig, filename='color-bar')
```

    Percentual com variações: 17.59%
    Percentual sem variações: 82.41%



![png](output_40_1.png)



```python

```
